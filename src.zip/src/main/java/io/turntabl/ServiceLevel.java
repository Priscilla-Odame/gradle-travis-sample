package io.turntabl;

public enum ServiceLevel {
    Gold, Platinum, Premium
}
